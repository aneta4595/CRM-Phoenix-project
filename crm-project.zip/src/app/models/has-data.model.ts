export interface HasDataModel <T> {
  readonly data: any;
}
