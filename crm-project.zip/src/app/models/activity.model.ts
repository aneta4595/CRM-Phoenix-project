export interface ActivityModel {
  readonly name: string;
  readonly id: string;
}
