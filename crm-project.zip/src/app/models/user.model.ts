export interface UserModel {
  readonly user_id: string;
  readonly email: string;
  readonly email_verified: boolean;
  readonly role: string;
}
