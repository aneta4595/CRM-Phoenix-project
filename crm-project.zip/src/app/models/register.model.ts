export interface RegisterModel {
  readonly email: string;
  readonly password: string;
}
