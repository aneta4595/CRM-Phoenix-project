export interface BioModel {
  readonly content: string;
}
