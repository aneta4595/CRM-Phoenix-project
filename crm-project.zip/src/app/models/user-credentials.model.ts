export interface UserCredentialsModel {
  readonly accessToken: string;
  readonly refreshToken: string;
}
