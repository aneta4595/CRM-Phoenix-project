export interface LeadSizeModel {
  
  readonly rangeId: string;
  readonly from: number;
  readonly to: number | null;
}
