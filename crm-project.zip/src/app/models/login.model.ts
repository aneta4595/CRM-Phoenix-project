export interface LoginModel {
  readonly email: string;
  readonly password: string;
}
