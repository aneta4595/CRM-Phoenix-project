export interface LeadsResponse <T>{
    readonly data: T

}