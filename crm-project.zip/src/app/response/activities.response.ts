export interface ActivitiesResponse <T>{
    readonly data: T
}