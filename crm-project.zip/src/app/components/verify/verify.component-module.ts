import { NgModule } from '@angular/core';
import { VerifyComponent } from './verify.component';

@NgModule({
  imports: [],
  declarations: [VerifyComponent],
  providers: [],
  exports: [VerifyComponent]
})
export class VerifyComponentModule {
}
