import { NgModule } from '@angular/core';
import { LogoutComponent } from './logout.component';

@NgModule({
  imports: [],
  declarations: [LogoutComponent],
  providers: [],
  exports: [LogoutComponent]
})
export class LogoutComponentModule {
}
